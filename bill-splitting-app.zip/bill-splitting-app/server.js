const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, "data", "bills.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function readBills() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return [];
  }
}

function saveBills(bills) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(bills, null, 2));
}

app.get("/api/bills", (req, res) => {
  res.json(readBills());
});

app.post("/api/bills", (req, res) => {
  const { title, total, people } = req.body;

  if (!title || !Number.isFinite(Number(total)) || Number(total) <= 0 ||
      !Array.isArray(people) || people.length < 1) {
    return res.status(400).json({ error: "Please provide a title, valid amount, and at least one person." });
  }

  const names = people.map(p => String(p).trim()).filter(Boolean);
  if (!names.length) {
    return res.status(400).json({ error: "Add at least one valid person's name." });
  }

  const amount = Number(total);
  const base = Math.floor((amount / names.length) * 100) / 100;
  const remainder = Math.round((amount - base * names.length) * 100) / 100;

  const shares = names.map((name, index) => ({
    name,
    amount: Number((base + (index === names.length - 1 ? remainder : 0)).toFixed(2))
  }));

  const bill = {
    id: Date.now().toString(),
    title: String(title).trim(),
    total: Number(amount.toFixed(2)),
    people: names,
    shares,
    createdAt: new Date().toISOString()
  };

  const bills = readBills();
  bills.unshift(bill);
  saveBills(bills);

  res.status(201).json(bill);
});

app.delete("/api/bills/:id", (req, res) => {
  const bills = readBills();
  const updated = bills.filter(bill => bill.id !== req.params.id);

  if (updated.length === bills.length) {
    return res.status(404).json({ error: "Bill not found." });
  }

  saveBills(updated);
  res.json({ message: "Bill deleted successfully." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`BillSplit is running at http://localhost:${PORT}`);
});