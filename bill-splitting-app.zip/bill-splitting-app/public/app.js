const form = document.getElementById("billForm");
const peopleList = document.getElementById("peopleList");
const addPerson = document.getElementById("addPerson");
const message = document.getElementById("message");
const result = document.getElementById("result");
const emptyResult = document.getElementById("emptyResult");
const shares = document.getElementById("shares");
const resultTotal = document.getElementById("resultTotal");
const history = document.getElementById("history");
const refreshHistory = document.getElementById("refreshHistory");

const money = value => new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  minimumFractionDigits: 2
}).format(value);

function attachRemoveButtons() {
  document.querySelectorAll(".remove-person").forEach(button => {
    button.onclick = () => {
      const rows = document.querySelectorAll(".person-row");
      if (rows.length > 1) button.closest(".person-row").remove();
    };
  });
}

addPerson.addEventListener("click", () => {
  const count = document.querySelectorAll(".person-row").length + 1;
  const row = document.createElement("div");
  row.className = "person-row";
  row.innerHTML = `
    <input type="text" class="person-input" placeholder="Person ${count}" required>
    <button type="button" class="remove-person" aria-label="Remove person">×</button>
  `;
  peopleList.appendChild(row);
  attachRemoveButtons();
  row.querySelector("input").focus();
});

attachRemoveButtons();

form.addEventListener("submit", async event => {
  event.preventDefault();
  message.textContent = "";

  const title = document.getElementById("title").value.trim();
  const total = Number(document.getElementById("total").value);
  const people = [...document.querySelectorAll(".person-input")]
    .map(input => input.value.trim())
    .filter(Boolean);

  if (!title || total <= 0 || people.length === 0) {
    message.textContent = "Please complete all bill details.";
    return;
  }

  try {
    const response = await fetch("/api/bills", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, total, people })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to save bill.");

    showResult(data);
    form.reset();
    peopleList.innerHTML = `
      <div class="person-row">
        <input type="text" class="person-input" placeholder="Person 1" required>
        <button type="button" class="remove-person" aria-label="Remove person">×</button>
      </div>
      <div class="person-row">
        <input type="text" class="person-input" placeholder="Person 2" required>
        <button type="button" class="remove-person" aria-label="Remove person">×</button>
      </div>
    `;
    attachRemoveButtons();
    loadHistory();
  } catch (error) {
    message.textContent = error.message;
  }
});

function showResult(bill) {
  emptyResult.classList.add("hidden");
  result.classList.remove("hidden");
  resultTotal.textContent = money(bill.total);

  shares.innerHTML = bill.shares.map(share => `
    <div class="share-row">
      <span>${escapeHtml(share.name)}</span>
      <strong>${money(share.amount)}</strong>
    </div>
  `).join("");
}

async function loadHistory() {
  try {
    const response = await fetch("/api/bills");
    const bills = await response.json();

    if (!bills.length) {
      history.innerHTML = '<p class="muted">No saved bills yet.</p>';
      return;
    }

    history.innerHTML = bills.map(bill => `
      <div class="history-item">
        <div class="history-info">
          <strong>${escapeHtml(bill.title)}</strong>
          <small>${bill.people.length} people · ${new Date(bill.createdAt).toLocaleDateString()}</small>
        </div>
        <strong>${money(bill.total)}</strong>
        <button class="delete-button" data-id="${bill.id}">Delete</button>
      </div>
    `).join("");

    document.querySelectorAll(".delete-button").forEach(button => {
      button.onclick = () => deleteBill(button.dataset.id);
    });
  } catch {
    history.innerHTML = '<p class="muted">Could not load bill history.</p>';
  }
}

async function deleteBill(id) {
  if (!confirm("Delete this saved bill?")) return;

  await fetch(`/api/bills/${id}`, { method: "DELETE" });
  loadHistory();
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[character]));
}

refreshHistory.addEventListener("click", loadHistory);
loadHistory();