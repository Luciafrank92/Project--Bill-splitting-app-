# BillSplit — Bill Splitting Application

## Project overview
BillSplit is a responsive full-stack web application that helps users divide a bill equally among a group of people. The app accepts a bill name, total amount and number of people, calculates each person's share, and stores previous bills for later viewing.

## Features
- Responsive modern interface
- Add and remove people dynamically
- Equal bill splitting
- Nigerian Naira (₦) currency formatting
- Automatic handling of rounding differences
- Saved bill history
- Delete saved bills
- REST API built with Node.js and Express
- JSON file persistence
- Input validation

## Technologies
- HTML5
- CSS3
- Vanilla JavaScript
- Node.js
- Express.js
- JSON file storage

## Requirements
Install Node.js on the computer.

## How to run
1. Open a terminal inside this project folder.
2. Run:
   `npm install`
3. Start the server:
   `npm start`
4. Open:
   `http://localhost:3000`

## API endpoints

### GET /api/bills
Returns all saved bills.

### POST /api/bills
Creates and saves a new bill.

Example JSON:
```json
{
  "title": "Dinner",
  "total": 25000,
  "people": ["Alice", "Bob", "David"]
}
```

### DELETE /api/bills/:id
Deletes a saved bill.

## Project structure

bill-splitting-app/
├── data/
│   └── bills.json
├── public/
│   ├── app.js
│   ├── index.html
│   └── style.css
├── package.json
├── README.md
└── server.js

## Project objective
The objective of this project is to demonstrate practical knowledge of frontend development, responsive design, JavaScript DOM manipulation, REST API development, server-side programming, validation, and basic data persistence.

## Future improvements
- User accounts and authentication
- Custom split percentages
- Receipt upload
- Payment tracking
- Cloud database
- Shareable bill links

## Author
Student Project — 2026
