const people = [];
let lastCalculation = null;

const $ = (id) => document.getElementById(id);

const billForm = $("billForm");
const personName = $("personName");
const peopleList = $("peopleList");
const peopleCount = $("peopleCount");
const resultContent = $("resultContent");
const emptyState = $("emptyState");
const statusPill = $("statusPill");
const toast = $("toast");

$("year").textContent = new Date().getFullYear();

function formatMoney(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 2
  }).format(value);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2400);
}

function initials(name) {
  return name
    .trim()
    .split(/\s+/)
    .map(word => word[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

function renderPeople() {
  peopleList.innerHTML = "";
  peopleCount.textContent = `${people.length} ${people.length === 1 ? "person" : "people"}`;

  people.forEach((person, index) => {
    const li = document.createElement("li");
    li.className = "person-row";
    li.innerHTML = `
      <div class="person-info">
        <span class="avatar">${initials(person)}</span>
        <span>${escapeHtml(person)}</span>
      </div>
      <button class="remove-person" type="button" data-index="${index}" aria-label="Remove ${escapeHtml(person)}">×</button>
    `;
    peopleList.appendChild(li);
  });

  document.querySelectorAll(".remove-person").forEach(button => {
    button.addEventListener("click", () => {
      people.splice(Number(button.dataset.index), 1);
      renderPeople();
      saveState();
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function addPerson() {
  const name = personName.value.trim();

  if (!name) {
    showToast("Please enter a person's name.");
    personName.focus();
    return;
  }

  if (people.some(person => person.toLowerCase() === name.toLowerCase())) {
    showToast("That person has already been added.");
    personName.select();
    return;
  }

  people.push(name);
  personName.value = "";
  personName.focus();
  renderPeople();
  saveState();
}

$("addPersonBtn").addEventListener("click", addPerson);

personName.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    addPerson();
  }
});

billForm.addEventListener("submit", (event) => {
  event.preventDefault();
  calculateSplit();
});

function calculateSplit() {
  const base = Number($("totalAmount").value);
  const tipPercent = Number($("tipPercent").value) || 0;
  const taxPercent = Number($("taxPercent").value) || 0;
  const equalSplit = $("equalSplit").checked;

  if (!Number.isFinite(base) || base <= 0) {
    showToast("Enter a bill amount greater than ₦0.");
    $("totalAmount").focus();
    return;
  }

  if (people.length < 2) {
    showToast("Add at least two people to split the bill.");
    personName.focus();
    return;
  }

  const tip = base * (tipPercent / 100);
  const tax = base * (taxPercent / 100);
  const total = base + tip + tax;
  const share = total / people.length;

  const shares = people.map(name => ({
    name,
    amount: share
  }));

  lastCalculation = {
    name: $("billName").value.trim() || "Bill",
    base,
    tip,
    tax,
    total,
    shares,
    equalSplit
  };

  renderResult(lastCalculation);
  saveState();
  showToast("Bill split calculated successfully.");
}

function renderResult(data) {
  emptyState.classList.add("hidden");
  resultContent.classList.remove("hidden");
  statusPill.textContent = "Calculated";
  statusPill.style.background = "#e8f8f1";
  statusPill.style.color = "#138a5b";

  $("finalTotal").textContent = formatMoney(data.total);
  $("perPerson").textContent = formatMoney(data.total / data.shares.length);
  $("baseAmount").textContent = formatMoney(data.base);
  $("tipAmount").textContent = formatMoney(data.tip);
  $("taxAmount").textContent = formatMoney(data.tax);

  $("resultList").innerHTML = data.shares.map(person => `
    <div class="result-row">
      <div class="result-person">
        <span class="avatar">${initials(person.name)}</span>
        <span>${escapeHtml(person.name)}</span>
      </div>
      <span class="result-amount">${formatMoney(person.amount)}</span>
    </div>
  `).join("");
}

$("copyBtn").addEventListener("click", async () => {
  if (!lastCalculation) return;

  const lines = [
    `${lastCalculation.name}`,
    `Total: ${formatMoney(lastCalculation.total)}`,
    "",
    ...lastCalculation.shares.map(person => `${person.name}: ${formatMoney(person.amount)}`)
  ];

  const text = lines.join("\n");

  try {
    await navigator.clipboard.writeText(text);
    showToast("Summary copied to clipboard.");
  } catch {
    showToast("Copy is not available in this browser.");
  }
});

$("clearAllBtn").addEventListener("click", () => {
  if (!confirm("Clear the bill, people and saved data?")) return;

  people.length = 0;
  lastCalculation = null;
  billForm.reset();
  $("tipPercent").value = 0;
  $("taxPercent").value = 0;
  $("equalSplit").checked = true;
  renderPeople();

  emptyState.classList.remove("hidden");
  resultContent.classList.add("hidden");
  statusPill.textContent = "Waiting";
  statusPill.removeAttribute("style");

  localStorage.removeItem("splitmate-state");
  showToast("All data cleared.");
});

function saveState() {
  const state = {
    billName: $("billName").value,
    totalAmount: $("totalAmount").value,
    tipPercent: $("tipPercent").value,
    taxPercent: $("taxPercent").value,
    equalSplit: $("equalSplit").checked,
    people,
    calculation: lastCalculation
  };

  localStorage.setItem("splitmate-state", JSON.stringify(state));
}

function loadState() {
  const saved = localStorage.getItem("splitmate-state");
  if (!saved) return;

  try {
    const state = JSON.parse(saved);

    $("billName").value = state.billName || "";
    $("totalAmount").value = state.totalAmount || "";
    $("tipPercent").value = state.tipPercent ?? 0;
    $("taxPercent").value = state.taxPercent ?? 0;
    $("equalSplit").checked = state.equalSplit !== false;

    people.push(...(Array.isArray(state.people) ? state.people : []));
    lastCalculation = state.calculation || null;

    renderPeople();

    if (lastCalculation) {
      renderResult(lastCalculation);
    }
  } catch {
    localStorage.removeItem("splitmate-state");
  }
}

["billName", "totalAmount", "tipPercent", "taxPercent", "equalSplit"].forEach(id => {
  $(id).addEventListener("input", saveState);
  $(id).addEventListener("change", saveState);
});

loadState();
