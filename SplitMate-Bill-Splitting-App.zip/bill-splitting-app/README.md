# SplitMate — Bill Splitting App

## Project overview
SplitMate is a responsive bill splitting web application built with HTML5, CSS3 and vanilla JavaScript. It allows users to enter a bill, apply optional tax and tip percentages, add members of a group, and calculate an equal share for every person.

## Features
- Responsive desktop and mobile design
- Bill name and total amount input
- Optional tip and tax calculations
- Add and remove people
- Equal bill splitting
- Individual payment breakdown
- Copy result summary to clipboard
- Local storage so the current project data survives a browser refresh
- Clear-all function
- Input validation and user-friendly notifications
- No external libraries or build tools required

## Technologies
- HTML5
- CSS3
- JavaScript (ES6+)
- Browser LocalStorage API
- Clipboard API

## How to run
1. Download or unzip the project.
2. Open `index.html` in a modern browser.
3. Enter a bill amount.
4. Add at least two people.
5. Optionally enter tax and tip percentages.
6. Click **Calculate Split**.

## Project structure
bill-splitting-app/
├── index.html
├── style.css
├── script.js
└── README.md

## Calculation formula
Tip = Bill × (Tip percentage ÷ 100)

Tax = Bill × (Tax percentage ÷ 100)

Final total = Bill + Tip + Tax

Each person's share = Final total ÷ Number of people

## Project objective
The objective of this project is to demonstrate practical knowledge of semantic HTML, responsive CSS, JavaScript DOM manipulation, form validation, browser storage, and basic application logic.

## Submission note
This is a front-end student project. It does not require Node.js, npm, a database, or a server. All calculations happen in the browser.
